function logout(){
    window.location.href = "/"
}
function listacadastro(){
    window.location.href = "/lista_produtos"
}
function promocao(){
    window.location.href = "/cadastro_promocao"
}
function cadastro_produto(){
    window.location.href = "/cadastro_produto"
}
function admin(){
    window.location.href = "/config_usuario"
}