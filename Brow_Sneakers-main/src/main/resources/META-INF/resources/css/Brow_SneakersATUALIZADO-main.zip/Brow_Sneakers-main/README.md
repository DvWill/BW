Projeto de desenvolvimento de um mercado digital utilizando Quarkus.
