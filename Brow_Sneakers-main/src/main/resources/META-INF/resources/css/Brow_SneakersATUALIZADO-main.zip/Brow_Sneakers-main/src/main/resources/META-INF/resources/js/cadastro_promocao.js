function voltar(){
    window.location.href = "/menu"
}
function promocao_cadastrada(){
    alert("Promoção Cadastrada!")
    window.location.href = "/menu"
}