function redirecionarParaPagina() {
    window.location.href = '/perfilgerente';
}