function voltar(){
    window.location.href = "/menu"
}
function salvarAlteracoes(){
    alert("Atualizações de perfil feitas!")
    window.location.href = "/menu"
}
